package com.example.dietmanager;

import okhttp3.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;

public class OpenAI {

    private static final String OPENAI_API_KEY = "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"; // OpenAI API 키
    private static final String OPENAI_URL = "https://api.openai.com/v1/chat/completions"; // Chat API 엔드포인트

    OkHttpClient client = new OkHttpClient();

    public void getChatCompletion(String prompt, ApiCallback callback) {
        // 요청 JSON 생성
        JSONObject jsonBody = new JSONObject();
        try {
            // 메시지 배열 생성
            JSONArray messages = new JSONArray();
            JSONObject message = new JSONObject();
            message.put("role", "user");
            message.put("content", prompt);
            messages.put(message);

            jsonBody.put("model", "gpt-3.5-turbo");  // gpt-3.5-turbo 모델 사용
            jsonBody.put("messages", messages);
            jsonBody.put("temperature", 0);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 요청 본문 설정
        RequestBody body = RequestBody.create(jsonBody.toString(), MediaType.get("application/json; charset=utf-8"));

        // HTTP 요청 생성
        Request request = new Request.Builder()
                .url(OPENAI_URL)
                .header("Authorization", "Bearer " + OPENAI_API_KEY) // 인증 헤더 추가
                .post(body)
                .build();

        // 비동기 요청
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                // 콜백을 통해 실패 알림
                if (callback != null) {
                    callback.onFailure(e);
                }
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseData = response.body().string(); // 응답 본문 읽기
                    try {
                        // 응답 JSON 파싱
                        JSONObject jsonResponse = new JSONObject(responseData);
                        JSONArray choices = jsonResponse.getJSONArray("choices");
                        if (choices.length() > 0) {
                            JSONObject firstChoice = choices.getJSONObject(0);
                            JSONObject message = firstChoice.getJSONObject("message");
                            String content = message.getString("content");

                            // 콜백을 통해 성공 알림
                            if (callback != null) {
                                callback.onSuccess(content);
                            }
                        } else {
                            if (callback != null) {
                                callback.onFailure(new IOException("No choices found in response"));
                            }
                        }
                    } catch (Exception e) {
                        if (callback != null) {
                            callback.onFailure(e);
                        }
                    }
                } else {
                    // 실패 메시지 출력 및 콜백 호출
                    if (callback != null) {
                        callback.onFailure(new IOException("Request failed: " + response.message()));
                    }
                }
            }
        });
    }
}