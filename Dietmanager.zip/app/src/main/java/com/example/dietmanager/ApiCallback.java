package com.example.dietmanager;

public interface ApiCallback {
    void onSuccess(String response);
    void onFailure(Throwable throwable);
}