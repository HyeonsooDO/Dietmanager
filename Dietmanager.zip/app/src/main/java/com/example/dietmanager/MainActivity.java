package com.example.dietmanager;

import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.Manifest;
import android.content.Intent;
import android.speech.*;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    //권한 상수
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 200;
    private SpeechRecognizer speechRecognizer;
    private Intent speechRecognizerIntent;
    private TextView textViewResult;
    private TextView textViewAI;
    private DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //메뉴 레이아웃
        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        Button menuButton = findViewById(R.id.menu_button);

        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(navigationView)) {
                    drawerLayout.closeDrawer(navigationView);
                } else {
                    drawerLayout.openDrawer(navigationView);
                }
            }
        });

        // 메뉴 아이템 클릭 리스너 설정
        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {

            } else if (id == R.id.nav_profile) {

            }
            drawerLayout.closeDrawers(); // 메뉴 닫기
            return true;
        });

        //openAI 객체 생성
        OpenAI openAIObj = new OpenAI();

        // 음성 인식 권한 확인 및 요청
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO},
                    REQUEST_RECORD_AUDIO_PERMISSION);
        }

        //데이터베이스
        DB db = new DB(this);
        Cursor userData = db.getUserData("1");
        if(userData.getCount()==0){
            //유저 데이터가 존재하지 않을 때

        }

        textViewResult = findViewById(R.id.textViewResult);
        textViewAI = findViewById(R.id.textViewAI);
        Button buttonSpeak = findViewById(R.id.buttonSpeak);

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
                Toast.makeText(MainActivity.this, "음성인식을 시작합니다.", Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onBeginningOfSpeech() {
            }
            @Override
            public void onRmsChanged(float rmsdB) {
            }
            @Override
            public void onBufferReceived(byte[] buffer) {
            }
            @Override
            public void onEndOfSpeech() {
            }
            @Override
            public void onError(int error) {
                Toast.makeText(MainActivity.this, "Error: " + error, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    String resultText = matches.get(0);
                    textViewResult.setText(resultText);

                    resultText += "내가 말하는 음식의 kcal를 모두 더해서 정리 해주고, 정확하지 않으면 평균적으로 계산해주고, 양을 말하지 않으면 1인분 기준으로 계산해주고, 1인분이나 1조각 처럼 단위를 명확하게 표기해줘.";
                    openAIObj.getChatCompletion(resultText, new ApiCallback() {
                        @Override
                        public void onSuccess(String response) {
                            textViewAI.setText(response);
                        }

                        @Override
                        public void onFailure(Throwable throwable) {
                            Toast.makeText(MainActivity.this, "오류가 발생했습니다.", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }

            @Override
            public void onPartialResults(Bundle partialResults) {
                // Called when partial results are received
            }

            @Override
            public void onEvent(int eventType, Bundle params) {
                // Called when an event occurs
            }
        });

        buttonSpeak.setOnClickListener(v -> startSpeechRecognition());
    }

    private void startSpeechRecognition() {
        if (speechRecognizer != null) {
            speechRecognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now");
            speechRecognizer.startListening(speechRecognizerIntent);
        }
    }

    @Override
    protected void onDestroy() {
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
        super.onDestroy();
    }
}