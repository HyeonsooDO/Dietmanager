package com.example.dietmanager;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DB extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "mydatabase.db";
    private static final int DATABASE_VERSION = 1;

    public DB(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    //DB 생성
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable_user = "CREATE TABLE userData (USERKEY TEXT, Name TEXT, Age INTEGER, Stature INTEGER, Weight INTEGER)";
        db.execSQL(createTable_user);
        String createTable_date = "CREATE TABLE dateData (Date TEXT, Food TEXT, Exercise TEXT)";
        db.execSQL(createTable_date);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS userData");
        db.execSQL("DROP TABLE IF EXISTS dateData");
        onCreate(db);
    }

    public Cursor getUserData(String user_key) {
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM userData WHERE USERKEY = ?";
        return db.rawQuery(selectQuery, new String[]{user_key});
    }
}